def compute_company_scores(session, top_k=50):
    # Placeholder scoring logic
    return []
