def summarize_entity(company_id, score, pillars):
    # Placeholder LLM call
    return f"## Summary for {company_id}\nScore: {score}\nSignals: {pillars}\n"
